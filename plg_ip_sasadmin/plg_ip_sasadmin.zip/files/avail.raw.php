<?php
/**
 * @version 3.3.2 2015-01-13
 * @package Joomla
 * @subpackage Intellectual Property
 * @copyright (C) 2009 - 2015 the Thinkery LLC. All rights reserved.
 * @license GNU/GPL see LICENSE.php
 */

defined( '_JEXEC' ) or die( 'Restricted access');
jimport('joomla.application.component.controller');

// Base this controller on the backend version.
require_once JPATH_ADMINISTRATOR.'/components/com_iproperty/controllers/avail.raw.php';

?>
