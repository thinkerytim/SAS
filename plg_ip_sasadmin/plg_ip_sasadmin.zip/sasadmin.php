<?php
/**
 * @version 3.3 2015-02-28
 * @package Joomla
 * @subpackage Intellectual Property
 * @copyright (C) 2009 - 2015 the Thinkery LLC. All rights reserved.
 * @license GNU/GPL see LICENSE.php
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin');
jimport('joomla.application.component.model');
JHtml::addIncludePath(JPATH_SITE.'/components/com_iproperty/helpers');

class plgIpropertySasadmin extends JPlugin
{
	private $settings;
	private $propdata;
	private $images;
	private $agents;
	private $amenities;
	
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->settings = ipropertyAdmin::config();
        $this->loadLanguage();
    }

    public function onAfterRenderPropertyEdit($property, $settings)
    {		
		$document = JFactory::getDocument();
		$date = new JDate();
		$i = 0;

		$document->addScript('//code.jquery.com/jquery-1.9.1.js');
		$document->addScript('//code.jquery.com/ui/1.10.3/jquery-ui.js');
		$document->addStyleSheet('//code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css');

		// set the listing id as a var for the javascript to access
		$script = 'var listing_id = '.$property->id.';'."\n";
		$document->addScriptDeclaration( $script );
		
		// now the javascript to do the request to the server
		$document->addScript(JURI::root().'/plugins/iproperty/sasadmin/sasadmin.js');
		
		$html  = '<div class="container-fluid">';
		$html .= '<div class="ip-sasadmin-calendar"></div>';
		$html .= '</div>';
		// build the tab
		echo JHtmlBootstrap::addTab('ip-propview', 'ip_sasadmin_tab', JText::_($this->params->get('tabtitle', 'PLG_IP_SASADMIN_TABTITLE')));
        echo $html;
		// close the tab	
        echo JHtmlBootstrap::endTab();
    }
}
